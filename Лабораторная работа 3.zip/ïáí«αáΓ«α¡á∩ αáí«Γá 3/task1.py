src = not False and True or False and not True

src = True and True or False and False
src = True or False


result = True

print(src == result)
